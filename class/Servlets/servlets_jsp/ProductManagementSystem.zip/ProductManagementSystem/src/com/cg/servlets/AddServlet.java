package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlets.dao.ProductDao;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String id=request.getParameter("id");
		String name=request.getParameter("name");
		String model=request.getParameter("model");
		String price=request.getParameter("price");
		ProductDao dao=new ProductDao();
		int n=dao.add(id,name,model,price);
		if(n>0){
			out.print("added successfully");
			RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
			rd.include(request,response);
		}
		else{
			RequestDispatcher rd=request.getRequestDispatcher("add.jsp?emsg=something went wrong, try agian");
			rd.include(request,response);
		}
	}
	}
