package com.cg.servlets.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ProductDao {
	Connection con=null;
	PreparedStatement ps=null;
	
	public Connection getConnection(){
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String user="system";
			String pass="Capgemini123";
			con=DriverManager.getConnection(url,user,pass);
			return con;
		}
		catch(Exception e){
		e.printStackTrace();	
		}
		return con;
	}
	
	public int registerUser(String username, String password, String mail, String mobile){
		con=getConnection();
		String sql="insert into user_details values(?,?,?,?)";
		try{
			ps=con.prepareStatement(sql);
			ps.setString(1,username);
			ps.setString(2,password);
			ps.setString(3,mail);
			ps.setString(4,mobile);
			int n=ps.executeUpdate();
			return n;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}
	
	public int forgotpassword(String username, String password, String confirmPass){
		con=getConnection();
		String sql="update user_details set password=? where username=?";
		try{
			ps=con.prepareStatement(sql);
			ps.setString(1,username);
			ps.setString(2,password);
			ps.setString(3,confirmPass);
			int n=ps.executeUpdate();
			return n;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}
	public boolean validateUser(String username, String password){
		try{
			con=getConnection();
			String sql="select * from user_details where password=?";
			ps=con.prepareStatement(sql);
			ps.setString(1,password);
			ResultSet rs=ps.executeQuery();
			return rs.next();
		}
		catch(Exception e){
			return false;
		}
}
	public int add(int id, String name, String model, double price){
		con=getConnection();
		String sql="insert into products values(?,?,?,?)";
		try{
			ps=con.prepareStatement(sql);
			ps.setInt(1, id);
			ps.setString(2,name);
			ps.setString(3,model);
			ps.setDouble(4,price);
			int n=ps.executeUpdate();
			return n;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return 0;
}
}
