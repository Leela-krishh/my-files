function submit(){
 var v2 = document.getElementById('ddate'),
      date = new Date(ddate.value),
      d1   = date.getTime(),
      d2   = new Date(sysdate).getTime(),
      d3   = new Date().getTime();

   if (d1 > d2 || d1 < d3) {
       return true;
   }else{
       alert("date is not in valid range")
   }
   return false;
}